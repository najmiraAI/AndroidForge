package com.kliktrigger

import android.content.Context

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("klik", Context.MODE_PRIVATE)
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    var enabled: Boolean
        get() = sp.getBoolean("on", false)
        set(v) = sp.edit().putBoolean("on", v).apply()

    var floating: Boolean
        get() = sp.getBoolean("float", true)
        set(v) = sp.edit().putBoolean("float", v).apply()

    var delayMs: Int
        get() = i("delay", 1000)
        set(v) = put("delay", v)

    var clicks: Int
        get() = i("clicks", 2)
        set(v) = put("clicks", v)

    var gapMs: Int
        get() = i("gap", 40)
        set(v) = put("gap", v)

    var tapMs: Int
        get() = i("tap", 30)
        set(v) = put("tap", v)

    var zoneDp: Int
        get() = i("zone", 110)
        set(v) = put("zone", v)

    // Titik tengah tombol 1 dan 2 di layar (px). -1 = belum diatur
    var x1: Int
        get() = i("x1", -1)
        set(v) = put("x1", v)
    var y1: Int
        get() = i("y1", -1)
        set(v) = put("y1", v)
    var x2: Int
        get() = i("x2", -1)
        set(v) = put("x2", v)
    var y2: Int
        get() = i("y2", -1)
        set(v) = put("y2", v)

    // Posisi tombol ON/OFF mengambang
    var bx: Int
        get() = i("bx", -1)
        set(v) = put("bx", v)
    var by: Int
        get() = i("by", -1)
        set(v) = put("by", v)
}
