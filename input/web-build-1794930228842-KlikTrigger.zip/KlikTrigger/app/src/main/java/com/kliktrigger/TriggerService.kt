package com.kliktrigger

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * Cara kerja:
 * - Zona transparan dipasang tepat di atas tombol 1 milik game.
 * - Saat zona disentuh: sentuhan diteruskan ke game sebagai ketukan di tombol 1,
 *   lalu setelah [Prefs.delayMs] ms tombol 2 diketuk [Prefs.clicks] kali.
 */
@SuppressLint("ClickableViewAccessibility")
class TriggerService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TriggerService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var p: Prefs
    private val handler = Handler(Looper.getMainLooper())

    private var zone: View? = null
    private var zoneLp: WindowManager.LayoutParams? = null
    private var toggle: View? = null
    private var m1: View? = null
    private var m2: View? = null
    private var saveBtn: View? = null

    private var calibrating = false
    private var busy = false        // hanya satu gesture pada satu waktu
    private var forwarding = false  // sedang meneruskan ketukan ke tombol 1

    private val dens: Float get() = resources.displayMetrics.density

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        p = Prefs(this)
        busy = false
        forwarding = false
        calibrating = false
        instance = this
        rebuild()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removeAll()
        instance = null
        return super.onUnbind(intent)
    }

    // ---------- dipanggil dari MainActivity ----------

    fun startCalibration() {
        calibrating = true
        rebuild()
    }

    fun rebuild() {
        removeAll()
        if (calibrating) {
            addCalibration()
            return
        }
        if (p.enabled) addZone()
        if (p.floating) addToggle()
    }

    // ---------- posisi ----------

    private fun screenW() = maxOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
    private fun screenH() = minOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)

    private fun pos1() =
        if (p.x1 >= 0) Pair(p.x1, p.y1) else Pair((screenW() * 0.80).toInt(), (screenH() * 0.65).toInt())

    private fun pos2() =
        if (p.x2 >= 0) Pair(p.x2, p.y2) else Pair((screenW() * 0.785).toInt(), (screenH() * 0.41).toInt())

    private fun center(v: View): Pair<Int, Int> {
        val l = IntArray(2)
        v.getLocationOnScreen(l)
        return Pair(l[0] + v.width / 2, l[1] + v.height / 2)
    }

    // ---------- window overlay ----------

    private fun params(w: Int, h: Int, x: Int, y: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = x
        lp.y = y
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun removeAll() {
        if (!::wm.isInitialized) return
        for (v in listOf(zone, toggle, m1, m2, saveBtn)) {
            if (v != null) try { wm.removeView(v) } catch (_: Exception) {}
        }
        zone = null; zoneLp = null; toggle = null; m1 = null; m2 = null; saveBtn = null
    }

    private fun badge(text: String, color: Int, sp: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = sp
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = 1000f
        }
    }

    private fun drag(v: View, lp: WindowManager.LayoutParams, onTap: (() -> Unit)?, onMoved: (() -> Unit)?) {
        var ox = 0f; var oy = 0f; var sx = 0f; var sy = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ox = lp.x - e.rawX; oy = lp.y - e.rawY
                    sx = e.rawX; sy = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 15 || abs(e.rawY - sy) > 15) moved = true
                    if (moved) {
                        lp.x = (e.rawX + ox).toInt()
                        lp.y = (e.rawY + oy).toInt()
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onMoved?.invoke() else onTap?.invoke()
                }
            }
            true
        }
    }

    // ---------- zona trigger (di atas tombol 1) ----------

    private fun addZone() {
        val s = (p.zoneDp * dens).toInt()
        val (cx, cy) = pos1()
        val v = View(this)
        v.setBackgroundColor(0x01000000)
        val lp = params(s, s, cx - s / 2, cy - s / 2)
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN && !forwarding) onPress()
            true
        }
        wm.addView(v, lp)
        zone = v
        zoneLp = lp
    }

    private fun onPress() {
        val z = zone ?: return
        val lp = zoneLp ?: return
        forwarding = true

        // 1) Zona dibuat "tembus sentuhan" sebentar supaya ketukan buatan sampai ke game
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(z, lp)

        handler.postDelayed({
            val (x, y) = pos1()
            tap(x, y, p.tapMs, 25) {
                lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                if (zone === z) wm.updateViewLayout(z, lp)
                forwarding = false
            }
        }, 45)

        // 2) Jadwalkan klik tombol 2
        handler.postDelayed({ runMacro(0) }, p.delayMs.toLong())
    }

    private fun runMacro(i: Int) {
        if (!p.enabled || calibrating || i >= p.clicks) return
        val (x, y) = pos2()
        tap(x, y, p.tapMs, 25) {
            if (i + 1 < p.clicks) handler.postDelayed({ runMacro(i + 1) }, p.gapMs.toLong())
        }
    }

    /** Satu ketukan. Kalau dibatalkan sistem (mis. jari lain menyentuh layar) akan diulang. */
    private fun tap(x: Int, y: Int, dur: Int, retries: Int, done: () -> Unit) {
        if (busy) {
            handler.postDelayed({ tap(x, y, dur, retries, done) }, 8)
            return
        }
        busy = true
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, maxOf(1, dur).toLong()))
            .build()
        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                busy = false
                done()
            }

            override fun onCancelled(g: GestureDescription?) {
                busy = false
                if (retries > 0) {
                    handler.postDelayed({ tap(x, y, dur, retries - 1, done) }, 15)
                } else {
                    done()
                }
            }
        }, handler)
        if (!ok) {
            busy = false
            done()
        }
    }

    // ---------- tombol ON/OFF mengambang ----------

    private fun addToggle() {
        val on = p.enabled
        val v = badge(if (on) "ON" else "OFF",
            if (on) Color.argb(220, 46, 125, 50) else Color.argb(220, 183, 28, 28), 12f)
        val lp = params(
            (50 * dens).toInt(), (30 * dens).toInt(),
            if (p.bx >= 0) p.bx else (12 * dens).toInt(),
            if (p.by >= 0) p.by else (110 * dens).toInt()
        )
        drag(v, lp,
            { p.enabled = !p.enabled; handler.post { rebuild() } },
            { p.bx = lp.x; p.by = lp.y })
        wm.addView(v, lp)
        toggle = v
    }

    // ---------- kalibrasi posisi ----------

    private fun addMarker(label: String, color: Int, size: Int, cx: Int, cy: Int): View {
        val v = badge(label, color, 22f)
        val lp = params(size, size, cx - size / 2, cy - size / 2)
        drag(v, lp, null, null)
        wm.addView(v, lp)
        return v
    }

    private fun addCalibration() {
        val s1 = (p.zoneDp * dens).toInt()
        val s2 = (s1 * 0.55f).toInt()
        val (a, b) = pos1()
        val (c, d) = pos2()
        m1 = addMarker("1", Color.argb(150, 255, 160, 0), s1, a, b)
        m2 = addMarker("2", Color.argb(150, 3, 169, 244), s2, c, d)

        val v = badge("SIMPAN POSISI  \u2713", Color.argb(230, 46, 125, 50), 16f)
        v.setPadding((20 * dens).toInt(), (10 * dens).toInt(), (20 * dens).toInt(), (10 * dens).toInt())
        val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            0, (16 * dens).toInt())
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) handler.post { finishCalibration() }
            true
        }
        wm.addView(v, lp)
        saveBtn = v
    }

    private fun finishCalibration() {
        m1?.let { val c = center(it); p.x1 = c.first; p.y1 = c.second }
        m2?.let { val c = center(it); p.x2 = c.first; p.y2 = c.second }
        calibrating = false
        rebuild()
        Toast.makeText(this, "Posisi tersimpan", Toast.LENGTH_SHORT).show()
    }
}
