package com.kliktrigger

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class Field(
        val edit: EditText,
        val range: IntRange,
        val read: () -> Int,
        val write: (Int) -> Unit
    )

    private lateinit var p: Prefs
    private lateinit var status: TextView
    private lateinit var swOn: Switch
    private val fields = ArrayList<Field>()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }

        fun label(s: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            text = s
            textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
        }

        root.addView(label("Klik Trigger", 26f, true))
        root.addView(label("Tekan tombol 1 \u2192 beberapa saat kemudian tombol 2 diklik otomatis.", 13f))
        status = label("", 15f, true)
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1. Aktifkan layanan Aksesibilitas"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "2. Atur posisi tombol 1 & 2"
            setOnClickListener {
                val s = TriggerService.instance
                if (s == null) {
                    toast("Aktifkan layanan Aksesibilitas dulu")
                } else {
                    s.startCalibration()
                    toast("Buka game, geser lingkaran 1 & 2 ke tombol di game, lalu tekan SIMPAN POSISI")
                    moveTaskToBack(true)
                }
            }
        })

        swOn = Switch(this).apply {
            text = "Trigger AKTIF (ON/OFF)"
            textSize = 16f
            setPadding(0, dp(16), 0, dp(8))
            isChecked = p.enabled
            setOnCheckedChangeListener { _, on ->
                if (p.enabled != on) {
                    p.enabled = on
                    TriggerService.instance?.rebuild()
                }
            }
        }
        root.addView(swOn)

        root.addView(Switch(this).apply {
            text = "Tampilkan tombol ON/OFF mengambang"
            setPadding(0, dp(8), 0, dp(8))
            isChecked = p.floating
            setOnCheckedChangeListener { _, on ->
                p.floating = on
                TriggerService.instance?.rebuild()
            }
        })

        root.addView(label("Pengaturan", 18f, true))

        fun field(name: String, range: IntRange, read: () -> Int, write: (Int) -> Unit) {
            root.addView(label(name, 13f))
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(read().toString())
            }
            root.addView(e)
            fields.add(Field(e, range, read, write))
        }
        field("Jeda sebelum klik tombol 2 (ms)", 0..10000, { p.delayMs }, { p.delayMs = it })
        field("Jumlah klik tombol 2", 1..20, { p.clicks }, { p.clicks = it })
        field("Jeda antar klik (ms)", 0..1000, { p.gapMs }, { p.gapMs = it })
        field("Lama tiap sentuhan (ms)", 5..500, { p.tapMs }, { p.tapMs = it })
        field("Ukuran zona tombol 1 (dp)", 40..300, { p.zoneDp }, { p.zoneDp = it })

        root.addView(Button(this).apply {
            text = "Simpan pengaturan"
            setOnClickListener {
                for (f in fields) {
                    val v = f.edit.text.toString().toIntOrNull() ?: continue
                    f.write(v.coerceIn(f.range.first, f.range.last))
                    f.edit.setText(f.read().toString())
                }
                TriggerService.instance?.rebuild()
                toast("Tersimpan")
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (TriggerService.instance != null) "Layanan: AKTIF \u2713" else "Layanan: belum aktif"
        swOn.isChecked = p.enabled
    }
}
